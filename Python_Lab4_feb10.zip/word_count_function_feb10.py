def wordcount(line):
    wc=line.split()
    return len(wc)
line=input("Enter a sentence")
res=wordcount(line)
print("Word count is:", res)
