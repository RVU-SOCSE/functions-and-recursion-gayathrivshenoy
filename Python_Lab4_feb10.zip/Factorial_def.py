def factorial(n):
    f=1;
    for i in range(1,n+1):
        f=f*i
    print("Factorial for n is", f)
    
n=int(input("Enter number"))
factorial(n)
