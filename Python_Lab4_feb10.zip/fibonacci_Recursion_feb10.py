def fibonacci(a, b, n):
    if n == 0:
        return
    print(a)
    fibonacci(b, a + b, n - 1)

n = int(input("Enter how many numbers you want: "))
fibonacci(0, 1, n)
